package POOwerCoders.modelo;

public interface IPedido {
    //Atributos (sin implementar, ya que es una interfaz)


    //Constructor (no es necesario ya que es una interfaz)


    //Getters y Setters (no se deben poner, ya que no presenta atributos implementados)


    //Metodos (sin implementar, ya que es una interfaz)
    double calcularPrecio();
    boolean cancelarPedido();
}
